// UK lang variables

tinyMCE.addI18n('en.lssupportinsertwikilink',{
	desc : 'Add link to a Wiki page'
});