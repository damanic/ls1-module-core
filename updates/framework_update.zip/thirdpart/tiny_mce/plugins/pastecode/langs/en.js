tinyMCE.addI18n('en.pastecode',{
	desc : 'Paste a code block'
});
