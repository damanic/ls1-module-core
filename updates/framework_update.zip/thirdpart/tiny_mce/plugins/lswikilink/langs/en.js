// UK lang variables

tinyMCE.addI18n('en.lswikilink',{
	desc : 'Add link to Wiki page'
});